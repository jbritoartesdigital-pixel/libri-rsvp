PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS events (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  event_date TEXT,
  event_time TEXT,
  rsvp_mode TEXT NOT NULL DEFAULT 'free' CHECK (rsvp_mode IN ('free', 'list')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  primary_color TEXT NOT NULL DEFAULT '#6f4f5f',
  accent_color TEXT NOT NULL DEFAULT '#f4e8ed',
  background_image_url TEXT,
  welcome_message TEXT,
  extra_fields_json TEXT NOT NULL DEFAULT '{}',
  client_access_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_events_slug ON events(slug);
CREATE INDEX IF NOT EXISTS idx_events_status ON events(status);

CREATE TABLE IF NOT EXISTS guests (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL,
  primary_name TEXT NOT NULL,
  phone TEXT,
  response_status TEXT NOT NULL DEFAULT 'pending' CHECK (response_status IN ('pending', 'yes', 'no')),
  adults INTEGER NOT NULL DEFAULT 1 CHECK (adults >= 0),
  children INTEGER NOT NULL DEFAULT 0 CHECK (children >= 0),
  companions_json TEXT NOT NULL DEFAULT '[]',
  dietary TEXT,
  notes TEXT,
  source TEXT NOT NULL DEFAULT 'public' CHECK (source IN ('public', 'client', 'admin', 'import')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_guests_event ON guests(event_id);
CREATE INDEX IF NOT EXISTS idx_guests_event_status ON guests(event_id, response_status);
CREATE INDEX IF NOT EXISTS idx_guests_event_name ON guests(event_id, primary_name);

CREATE TABLE IF NOT EXISTS audit_log (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL,
  guest_id TEXT,
  actor_role TEXT NOT NULL CHECK (actor_role IN ('admin', 'client', 'public', 'system')),
  action TEXT NOT NULL,
  details_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL,
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_audit_event_created ON audit_log(event_id, created_at DESC);
