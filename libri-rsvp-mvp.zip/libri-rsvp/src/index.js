const enc = new TextEncoder();
const dec = new TextDecoder();

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    try {
      if (url.pathname.startsWith('/api/')) {
        return await handleApi(request, env, url);
      }

      if (url.pathname === '/admin' || url.pathname.startsWith('/cliente/') || url.pathname.startsWith('/e/')) {
        return env.ASSETS.fetch(new Request(new URL('/index.html', url.origin), request));
      }

      return env.ASSETS.fetch(request);
    } catch (error) {
      console.error(JSON.stringify({ message: 'request_failed', path: url.pathname, error: error?.stack || String(error) }));
      return json({ error: 'Erro interno. Tente novamente.' }, 500);
    }
  }
};

async function handleApi(request, env, url) {
  const { pathname } = url;

  if (pathname === '/api/health') return json({ ok: true, service: 'libri-rsvp' });

  if (pathname === '/api/admin/login' && request.method === 'POST') {
    return adminLogin(request, env);
  }
  if (pathname === '/api/admin/logout' && request.method === 'POST') {
    return json({ ok: true }, 200, { 'Set-Cookie': clearAdminCookie() });
  }
  if (pathname === '/api/admin/me' && request.method === 'GET') {
    const admin = await requireAdmin(request, env);
    if (!admin) return json({ authenticated: false }, 401);
    return json({ authenticated: true, role: 'admin' });
  }

  if (pathname.startsWith('/api/admin/')) {
    const admin = await requireAdmin(request, env);
    if (!admin) return json({ error: 'Não autorizado.' }, 401);
    if (isMutation(request) && !sameOrigin(request)) return json({ error: 'Origem inválida.' }, 403);
    return handleAdmin(request, env, url);
  }

  if (pathname.startsWith('/api/client/')) {
    if (isMutation(request) && !sameOrigin(request)) return json({ error: 'Origem inválida.' }, 403);
    return handleClient(request, env, url);
  }

  if (pathname.startsWith('/api/public/')) {
    return handlePublic(request, env, url);
  }

  return json({ error: 'Rota não encontrada.' }, 404);
}

async function adminLogin(request, env) {
  if (!env.ADMIN_PASSWORD || !env.SESSION_SECRET) {
    return json({ error: 'Configure ADMIN_PASSWORD e SESSION_SECRET no Cloudflare.' }, 503);
  }
  if (!sameOrigin(request)) return json({ error: 'Origem inválida.' }, 403);
  const body = await readJson(request);
  if (!body?.password) return json({ error: 'Informe a senha.' }, 400);
  const ok = await safeSecretEqual(String(body.password), env.ADMIN_PASSWORD, env.SESSION_SECRET);
  if (!ok) return json({ error: 'Senha incorreta.' }, 401);

  const token = await createSessionToken({ role: 'admin', exp: Date.now() + 12 * 60 * 60 * 1000 }, env.SESSION_SECRET);
  return json({ ok: true }, 200, { 'Set-Cookie': adminCookie(token) });
}

async function handleAdmin(request, env, url) {
  const path = url.pathname.replace('/api/admin', '');

  if (path === '/events' && request.method === 'GET') {
    const rows = await env.DB.prepare(`
      SELECT e.*,
        SUM(CASE WHEN g.deleted_at IS NULL AND g.response_status='yes' THEN 1 ELSE 0 END) AS yes_responses,
        SUM(CASE WHEN g.deleted_at IS NULL AND g.response_status='no' THEN 1 ELSE 0 END) AS no_responses,
        SUM(CASE WHEN g.deleted_at IS NULL AND g.response_status='pending' THEN 1 ELSE 0 END) AS pending_responses,
        SUM(CASE WHEN g.deleted_at IS NULL AND g.response_status='yes' THEN g.adults + g.children ELSE 0 END) AS people_confirmed
      FROM events e
      LEFT JOIN guests g ON g.event_id=e.id
      GROUP BY e.id
      ORDER BY COALESCE(e.event_date, '9999-12-31') ASC, e.created_at DESC
    `).all();
    return json({ events: rows.results.map(publicEventShape) });
  }

  if (path === '/events' && request.method === 'POST') {
    const body = await readJson(request);
    const title = cleanText(body?.title, 120);
    if (!title) return json({ error: 'Informe o nome do evento.' }, 400);
    const slug = await uniqueSlug(env.DB, body?.slug || title);
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    const mode = body?.rsvp_mode === 'list' ? 'list' : 'free';
    const extra = normalizeExtraFields(body?.extra_fields);

    await env.DB.prepare(`
      INSERT INTO events (id, slug, title, event_date, event_time, rsvp_mode, status, primary_color, accent_color, background_image_url, welcome_message, extra_fields_json, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      id, slug, title, nullableDate(body?.event_date), cleanText(body?.event_time, 10), mode,
      validHex(body?.primary_color) || '#6f4f5f', validHex(body?.accent_color) || '#f4e8ed',
      cleanUrl(body?.background_image_url), cleanText(body?.welcome_message, 500), JSON.stringify(extra), now, now
    ).run();

    await audit(env.DB, id, null, 'admin', 'event_created', { title, mode });
    const event = await getEvent(env.DB, id);
    return json({ event: publicEventShape(event), client_url: await clientUrl(url.origin, event, env) }, 201);
  }

  const eventMatch = path.match(/^\/events\/([^/]+)$/);
  if (eventMatch) {
    const eventId = eventMatch[1];
    if (request.method === 'GET') {
      const event = await getEvent(env.DB, eventId);
      if (!event) return json({ error: 'Evento não encontrado.' }, 404);
      const summary = await eventSummary(env.DB, eventId);
      return json({ event: publicEventShape(event), summary, client_url: await clientUrl(url.origin, event, env) });
    }
    if (request.method === 'PATCH') {
      const body = await readJson(request);
      const event = await getEvent(env.DB, eventId);
      if (!event) return json({ error: 'Evento não encontrado.' }, 404);
      const next = {
        title: cleanText(body?.title ?? event.title, 120) || event.title,
        event_date: body?.event_date === undefined ? event.event_date : nullableDate(body.event_date),
        event_time: body?.event_time === undefined ? event.event_time : cleanText(body.event_time, 10),
        rsvp_mode: body?.rsvp_mode === undefined ? event.rsvp_mode : (body.rsvp_mode === 'list' ? 'list' : 'free'),
        status: body?.status === undefined ? event.status : (body.status === 'inactive' ? 'inactive' : 'active'),
        primary_color: validHex(body?.primary_color) || event.primary_color,
        accent_color: validHex(body?.accent_color) || event.accent_color,
        background_image_url: body?.background_image_url === undefined ? event.background_image_url : cleanUrl(body.background_image_url),
        welcome_message: body?.welcome_message === undefined ? event.welcome_message : cleanText(body.welcome_message, 500),
        extra_fields_json: body?.extra_fields === undefined ? event.extra_fields_json : JSON.stringify(normalizeExtraFields(body.extra_fields)),
      };
      await env.DB.prepare(`UPDATE events SET title=?, event_date=?, event_time=?, rsvp_mode=?, status=?, primary_color=?, accent_color=?, background_image_url=?, welcome_message=?, extra_fields_json=?, updated_at=? WHERE id=?`)
        .bind(next.title, next.event_date, next.event_time, next.rsvp_mode, next.status, next.primary_color, next.accent_color, next.background_image_url, next.welcome_message, next.extra_fields_json, new Date().toISOString(), eventId).run();
      await audit(env.DB, eventId, null, 'admin', 'event_updated', {});
      return json({ event: publicEventShape(await getEvent(env.DB, eventId)) });
    }
  }

  const resetMatch = path.match(/^\/events\/([^/]+)\/client-link\/reset$/);
  if (resetMatch && request.method === 'POST') {
    const eventId = resetMatch[1];
    const event = await getEvent(env.DB, eventId);
    if (!event) return json({ error: 'Evento não encontrado.' }, 404);
    await env.DB.prepare('UPDATE events SET client_access_version = client_access_version + 1, updated_at=? WHERE id=?')
      .bind(new Date().toISOString(), eventId).run();
    const updated = await getEvent(env.DB, eventId);
    await audit(env.DB, eventId, null, 'admin', 'client_link_reset', {});
    return json({ client_url: await clientUrl(url.origin, updated, env) });
  }

  const guestBase = path.match(/^\/events\/([^/]+)\/guests$/);
  if (guestBase) {
    const eventId = guestBase[1];
    if (!(await getEvent(env.DB, eventId))) return json({ error: 'Evento não encontrado.' }, 404);
    if (request.method === 'GET') return listGuests(env.DB, eventId, url.searchParams);
    if (request.method === 'POST') return createGuest(request, env.DB, eventId, 'admin');
  }

  const guestItem = path.match(/^\/events\/([^/]+)\/guests\/([^/]+)$/);
  if (guestItem) {
    const [, eventId, guestId] = guestItem;
    if (request.method === 'PATCH') return updateGuest(request, env.DB, eventId, guestId, 'admin');
    if (request.method === 'DELETE') return removeGuest(env.DB, eventId, guestId, 'admin');
  }

  const auditMatch = path.match(/^\/events\/([^/]+)\/audit$/);
  if (auditMatch && request.method === 'GET') {
    const rows = await env.DB.prepare('SELECT * FROM audit_log WHERE event_id=? ORDER BY created_at DESC LIMIT 200').bind(auditMatch[1]).all();
    return json({ audit: rows.results.map(row => ({ ...row, details: parseJson(row.details_json, {}) })) });
  }

  const exportMatch = path.match(/^\/events\/([^/]+)\/export\.csv$/);
  if (exportMatch && request.method === 'GET') {
    const event = await getEvent(env.DB, exportMatch[1]);
    if (!event) return json({ error: 'Evento não encontrado.' }, 404);
    const rows = await env.DB.prepare('SELECT * FROM guests WHERE event_id=? AND deleted_at IS NULL ORDER BY primary_name COLLATE NOCASE').bind(event.id).all();
    const csvText = makeCsv(rows.results);
    return new Response('\uFEFF' + csvText, {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="${safeFilename(event.slug)}-confirmacoes.csv"`,
        'Cache-Control': 'no-store'
      }
    });
  }

  return json({ error: 'Rota administrativa não encontrada.' }, 404);
}

async function handleClient(request, env, url) {
  const match = url.pathname.match(/^\/api\/client\/([^/]+)(\/.*)?$/);
  if (!match) return json({ error: 'Link inválido.' }, 404);
  const token = decodeURIComponent(match[1]);
  const subpath = match[2] || '';
  const auth = await verifyClientToken(token, env);
  if (!auth) return json({ error: 'Este link de acesso é inválido ou foi substituído.' }, 401);
  const event = auth.event;

  if (subpath === '/event' && request.method === 'GET') {
    return json({ event: publicEventShape(event), summary: await eventSummary(env.DB, event.id) });
  }
  if (subpath === '/guests' && request.method === 'GET') return listGuests(env.DB, event.id, url.searchParams);
  if (subpath === '/guests' && request.method === 'POST') return createGuest(request, env.DB, event.id, 'client');

  const guestItem = subpath.match(/^\/guests\/([^/]+)$/);
  if (guestItem) {
    if (request.method === 'PATCH') return updateGuest(request, env.DB, event.id, guestItem[1], 'client');
    if (request.method === 'DELETE') return removeGuest(env.DB, event.id, guestItem[1], 'client');
  }

  if (subpath === '/export.csv' && request.method === 'GET') {
    const rows = await env.DB.prepare('SELECT * FROM guests WHERE event_id=? AND deleted_at IS NULL ORDER BY primary_name COLLATE NOCASE').bind(event.id).all();
    return new Response('\uFEFF' + makeCsv(rows.results), {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="${safeFilename(event.slug)}-confirmacoes.csv"`,
        'Cache-Control': 'no-store'
      }
    });
  }

  return json({ error: 'Rota do cliente não encontrada.' }, 404);
}

async function handlePublic(request, env, url) {
  const eventMatch = url.pathname.match(/^\/api\/public\/events\/([^/]+)$/);
  if (eventMatch && request.method === 'GET') {
    const event = await getEventBySlug(env.DB, eventMatch[1]);
    if (!event || event.status !== 'active') return json({ error: 'Evento indisponível.' }, 404);
    return json({ event: publicEventShape(event), turnstile_sitekey: env.TURNSTILE_SITEKEY || null });
  }

  const lookupMatch = url.pathname.match(/^\/api\/public\/events\/([^/]+)\/lookup$/);
  if (lookupMatch && request.method === 'POST') {
    const event = await getEventBySlug(env.DB, lookupMatch[1]);
    if (!event || event.status !== 'active') return json({ error: 'Evento indisponível.' }, 404);
    if (event.rsvp_mode !== 'list') return json({ error: 'Este evento não usa lista pré-cadastrada.' }, 400);
    const body = await readJson(request);
    const name = cleanText(body?.name, 120);
    if (!name || name.length < 3) return json({ error: 'Digite seu nome completo.' }, 400);
    const row = await env.DB.prepare(`SELECT id, primary_name, response_status, adults, children, companions_json FROM guests WHERE event_id=? AND deleted_at IS NULL AND LOWER(TRIM(primary_name)) = LOWER(TRIM(?)) LIMIT 1`)
      .bind(event.id, name).first();
    if (!row) return json({ found: false, message: 'Nome não encontrado. Confira a escrita ou fale com o anfitrião.' }, 404);
    return json({ found: true, guest: guestShape(row) });
  }

  const rsvpMatch = url.pathname.match(/^\/api\/public\/events\/([^/]+)\/rsvp$/);
  if (rsvpMatch && request.method === 'POST') {
    const event = await getEventBySlug(env.DB, rsvpMatch[1]);
    if (!event || event.status !== 'active') return json({ error: 'Evento indisponível.' }, 404);
    const body = await readJson(request);
    const turnstileOk = await verifyTurnstile(body?.turnstile_token, request, env);
    if (!turnstileOk) return json({ error: 'Não foi possível validar o envio. Tente novamente.' }, 400);

    const responseStatus = body?.response_status === 'no' ? 'no' : 'yes';
    if (event.rsvp_mode === 'list') {
      const guestId = cleanText(body?.guest_id, 80);
      const primaryName = cleanText(body?.primary_name, 120);
      if (!guestId || !primaryName) return json({ error: 'Localize seu nome na lista primeiro.' }, 400);
      const existing = await env.DB.prepare('SELECT * FROM guests WHERE id=? AND event_id=? AND deleted_at IS NULL').bind(guestId, event.id).first();
      if (!existing || normalizeName(existing.primary_name) !== normalizeName(primaryName)) return json({ error: 'Convidado não encontrado.' }, 404);
      const patch = normalizeGuestInput(body, existing);
      await env.DB.prepare(`UPDATE guests SET response_status=?, adults=?, children=?, companions_json=?, phone=?, dietary=?, notes=?, updated_at=? WHERE id=? AND event_id=?`)
        .bind(responseStatus, responseStatus === 'no' ? 0 : patch.adults, responseStatus === 'no' ? 0 : patch.children, responseStatus === 'no' ? '[]' : JSON.stringify(patch.companions), patch.phone, patch.dietary, patch.notes, new Date().toISOString(), guestId, event.id).run();
      await audit(env.DB, event.id, guestId, 'public', 'rsvp_updated', { response_status: responseStatus });
      return json({ ok: true, guest: guestShape(await getGuest(env.DB, event.id, guestId)) });
    }

    const primaryName = cleanText(body?.primary_name, 120);
    if (!primaryName) return json({ error: 'Informe seu nome.' }, 400);
    const duplicate = await env.DB.prepare(`SELECT id, primary_name, response_status FROM guests WHERE event_id=? AND deleted_at IS NULL AND LOWER(TRIM(primary_name)) = LOWER(TRIM(?)) LIMIT 1`)
      .bind(event.id, primaryName).first();
    if (duplicate) return json({ error: 'Já existe uma confirmação com esse nome. Se precisar alterar, fale com o anfitrião.', duplicate: true }, 409);

    const normalized = normalizeGuestInput(body, { primary_name: primaryName });
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    await env.DB.prepare(`INSERT INTO guests (id,event_id,primary_name,phone,response_status,adults,children,companions_json,dietary,notes,source,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?, 'public', ?,?)`)
      .bind(id, event.id, primaryName, normalized.phone, responseStatus, responseStatus === 'no' ? 0 : normalized.adults, responseStatus === 'no' ? 0 : normalized.children, responseStatus === 'no' ? '[]' : JSON.stringify(normalized.companions), normalized.dietary, normalized.notes, now, now).run();
    await audit(env.DB, event.id, id, 'public', 'rsvp_created', { response_status: responseStatus });
    return json({ ok: true, guest: guestShape(await getGuest(env.DB, event.id, id)) }, 201);
  }

  return json({ error: 'Rota pública não encontrada.' }, 404);
}

async function createGuest(request, db, eventId, actor) {
  const body = await readJson(request);
  const name = cleanText(body?.primary_name, 120);
  if (!name) return json({ error: 'Informe o nome do convidado.' }, 400);
  const data = normalizeGuestInput(body, { primary_name: name });
  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  const status = ['yes','no','pending'].includes(body?.response_status) ? body.response_status : 'pending';
  await db.prepare(`INSERT INTO guests (id,event_id,primary_name,phone,response_status,adults,children,companions_json,dietary,notes,source,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .bind(id, eventId, name, data.phone, status, status === 'no' ? 0 : data.adults, status === 'no' ? 0 : data.children, status === 'no' ? '[]' : JSON.stringify(data.companions), data.dietary, data.notes, actor, now, now).run();
  await audit(db, eventId, id, actor, 'guest_created', { name, response_status: status });
  return json({ guest: guestShape(await getGuest(db, eventId, id)) }, 201);
}

async function updateGuest(request, db, eventId, guestId, actor) {
  const existing = await getGuest(db, eventId, guestId);
  if (!existing || existing.deleted_at) return json({ error: 'Convidado não encontrado.' }, 404);
  const body = await readJson(request);
  const data = normalizeGuestInput(body, existing);
  const name = cleanText(body?.primary_name ?? existing.primary_name, 120) || existing.primary_name;
  const status = ['yes','no','pending'].includes(body?.response_status) ? body.response_status : existing.response_status;
  await db.prepare(`UPDATE guests SET primary_name=?, phone=?, response_status=?, adults=?, children=?, companions_json=?, dietary=?, notes=?, updated_at=? WHERE id=? AND event_id=?`)
    .bind(name, data.phone, status, status === 'no' ? 0 : data.adults, status === 'no' ? 0 : data.children, status === 'no' ? '[]' : JSON.stringify(data.companions), data.dietary, data.notes, new Date().toISOString(), guestId, eventId).run();
  await audit(db, eventId, guestId, actor, 'guest_updated', { name, response_status: status });
  return json({ guest: guestShape(await getGuest(db, eventId, guestId)) });
}

async function removeGuest(db, eventId, guestId, actor) {
  const existing = await getGuest(db, eventId, guestId);
  if (!existing || existing.deleted_at) return json({ error: 'Convidado não encontrado.' }, 404);
  await db.prepare('UPDATE guests SET deleted_at=?, updated_at=? WHERE id=? AND event_id=?').bind(new Date().toISOString(), new Date().toISOString(), guestId, eventId).run();
  await audit(db, eventId, guestId, actor, 'guest_removed', { name: existing.primary_name });
  return json({ ok: true });
}

async function listGuests(db, eventId, params) {
  const q = cleanText(params.get('q'), 80);
  const status = params.get('status');
  const where = ['event_id=?', 'deleted_at IS NULL'];
  const binds = [eventId];
  if (q) { where.push('LOWER(primary_name) LIKE LOWER(?)'); binds.push(`%${q}%`); }
  if (['yes','no','pending'].includes(status)) { where.push('response_status=?'); binds.push(status); }
  const rows = await db.prepare(`SELECT * FROM guests WHERE ${where.join(' AND ')} ORDER BY primary_name COLLATE NOCASE LIMIT 1000`).bind(...binds).all();
  return json({ guests: rows.results.map(guestShape), summary: await eventSummary(db, eventId) });
}

async function eventSummary(db, eventId) {
  const row = await db.prepare(`SELECT
    SUM(CASE WHEN deleted_at IS NULL AND response_status='yes' THEN 1 ELSE 0 END) AS yes_responses,
    SUM(CASE WHEN deleted_at IS NULL AND response_status='no' THEN 1 ELSE 0 END) AS no_responses,
    SUM(CASE WHEN deleted_at IS NULL AND response_status='pending' THEN 1 ELSE 0 END) AS pending_responses,
    SUM(CASE WHEN deleted_at IS NULL AND response_status='yes' THEN adults + children ELSE 0 END) AS people_confirmed,
    COUNT(CASE WHEN deleted_at IS NULL THEN 1 END) AS total_records
    FROM guests WHERE event_id=?`).bind(eventId).first();
  return {
    yes_responses: Number(row?.yes_responses || 0),
    no_responses: Number(row?.no_responses || 0),
    pending_responses: Number(row?.pending_responses || 0),
    people_confirmed: Number(row?.people_confirmed || 0),
    total_records: Number(row?.total_records || 0)
  };
}

async function getEvent(db, id) { return db.prepare('SELECT * FROM events WHERE id=?').bind(id).first(); }
async function getEventBySlug(db, slug) { return db.prepare('SELECT * FROM events WHERE slug=?').bind(slug).first(); }
async function getGuest(db, eventId, guestId) { return db.prepare('SELECT * FROM guests WHERE id=? AND event_id=?').bind(guestId, eventId).first(); }

function publicEventShape(e) {
  if (!e) return null;
  return {
    id: e.id, slug: e.slug, title: e.title, event_date: e.event_date, event_time: e.event_time,
    rsvp_mode: e.rsvp_mode, status: e.status, primary_color: e.primary_color, accent_color: e.accent_color,
    background_image_url: e.background_image_url, welcome_message: e.welcome_message,
    extra_fields: parseJson(e.extra_fields_json, {}), created_at: e.created_at, updated_at: e.updated_at,
    yes_responses: Number(e.yes_responses || 0), no_responses: Number(e.no_responses || 0),
    pending_responses: Number(e.pending_responses || 0), people_confirmed: Number(e.people_confirmed || 0)
  };
}

function guestShape(g) {
  if (!g) return null;
  return {
    id: g.id, primary_name: g.primary_name, phone: g.phone || '', response_status: g.response_status,
    adults: Number(g.adults || 0), children: Number(g.children || 0), companions: parseJson(g.companions_json, []),
    dietary: g.dietary || '', notes: g.notes || '', source: g.source, created_at: g.created_at, updated_at: g.updated_at
  };
}

function normalizeGuestInput(body, existing = {}) {
  const companions = Array.isArray(body?.companions) ? body.companions.map(x => cleanText(x, 120)).filter(Boolean).slice(0, 20) : parseJson(existing.companions_json, existing.companions || []);
  return {
    phone: body?.phone === undefined ? (existing.phone || null) : cleanText(body.phone, 40),
    adults: clampInt(body?.adults === undefined ? existing.adults ?? 1 : body.adults, 0, 50),
    children: clampInt(body?.children === undefined ? existing.children ?? 0 : body.children, 0, 50),
    companions,
    dietary: body?.dietary === undefined ? (existing.dietary || null) : cleanText(body.dietary, 500),
    notes: body?.notes === undefined ? (existing.notes || null) : cleanText(body.notes, 800)
  };
}

function normalizeExtraFields(input) {
  const x = input && typeof input === 'object' ? input : {};
  return {
    phone: Boolean(x.phone), adults_children: x.adults_children !== false,
    companions: x.companions !== false, dietary: Boolean(x.dietary), notes: Boolean(x.notes)
  };
}

async function audit(db, eventId, guestId, actorRole, action, details) {
  await db.prepare('INSERT INTO audit_log (id,event_id,guest_id,actor_role,action,details_json,created_at) VALUES (?,?,?,?,?,?,?)')
    .bind(crypto.randomUUID(), eventId, guestId, actorRole, action, JSON.stringify(details || {}), new Date().toISOString()).run();
}

async function uniqueSlug(db, value) {
  const base = slugify(value) || `evento-${crypto.randomUUID().slice(0, 6)}`;
  let candidate = base;
  for (let i = 2; i < 100; i++) {
    const exists = await db.prepare('SELECT 1 FROM events WHERE slug=?').bind(candidate).first();
    if (!exists) return candidate;
    candidate = `${base}-${i}`;
  }
  return `${base}-${crypto.randomUUID().slice(0, 6)}`;
}

function slugify(value) {
  return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 70);
}
function normalizeName(value) { return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim(); }
function cleanText(v, max=255) { if (v === null || v === undefined) return null; const s=String(v).trim().slice(0,max); return s || null; }
function cleanUrl(v) { const s=cleanText(v, 1000); if (!s) return null; try { const u=new URL(s); return ['http:','https:'].includes(u.protocol) ? u.href : null; } catch { return null; } }
function validHex(v) { const s=String(v || ''); return /^#[0-9a-fA-F]{6}$/.test(s) ? s : null; }
function nullableDate(v) { const s=cleanText(v, 10); return s && /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : null; }
function clampInt(v,min,max){ const n=Number.parseInt(v,10); return Number.isFinite(n)?Math.max(min,Math.min(max,n)):min; }
function parseJson(v, fallback){ try { return typeof v === 'string' ? JSON.parse(v) : (v ?? fallback); } catch { return fallback; } }
function readJson(req){ return req.json().catch(()=>null); }
function isMutation(req){ return !['GET','HEAD','OPTIONS'].includes(req.method); }
function sameOrigin(request){ const origin=request.headers.get('Origin'); if(!origin) return true; try { return new URL(origin).host === new URL(request.url).host; } catch { return false; } }

async function verifyTurnstile(token, request, env) {
  if (!env.TURNSTILE_SECRET) return true;
  if (!token) return false;
  const form = new FormData();
  form.append('secret', env.TURNSTILE_SECRET);
  form.append('response', String(token));
  const ip = request.headers.get('CF-Connecting-IP');
  if (ip) form.append('remoteip', ip);
  try {
    const res = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', { method:'POST', body:form });
    const data = await res.json();
    return data.success === true;
  } catch { return false; }
}

function adminCookie(token){ return `libri_admin=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=43200`; }
function clearAdminCookie(){ return 'libri_admin=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0'; }
function cookieValue(req,name){ const raw=req.headers.get('Cookie')||''; for(const item of raw.split(';')){ const [k,...rest]=item.trim().split('='); if(k===name) return rest.join('='); } return null; }

async function requireAdmin(request, env){
  if(!env.SESSION_SECRET) return null;
  const token=cookieValue(request,'libri_admin');
  if(!token) return null;
  const data=await verifySessionToken(token,env.SESSION_SECRET);
  return data?.role==='admin' && data.exp>Date.now() ? data : null;
}

async function createSessionToken(payload, secret){
  const p=b64url(enc.encode(JSON.stringify(payload)));
  const sig=b64url(new Uint8Array(await hmac(secret,p)));
  return `${p}.${sig}`;
}
async function verifySessionToken(token, secret){
  const [p,s]=String(token).split('.'); if(!p||!s) return null;
  const expected=new Uint8Array(await hmac(secret,p)); const actual=fromB64url(s);
  if(expected.byteLength!==actual.byteLength || !crypto.subtle.timingSafeEqual(expected,actual)) return null;
  try{return JSON.parse(dec.decode(fromB64url(p)));}catch{return null;}
}
async function safeSecretEqual(a,b,key){
  const [ha,hb]=await Promise.all([hmac(key,String(a)),hmac(key,String(b))]);
  return crypto.subtle.timingSafeEqual(new Uint8Array(ha),new Uint8Array(hb));
}
async function hmac(secret,data){
  const key=await crypto.subtle.importKey('raw',enc.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  return crypto.subtle.sign('HMAC',key,enc.encode(data));
}
function b64url(bytes){ let s=''; for(const b of bytes)s+=String.fromCharCode(b); return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,''); }
function fromB64url(s){ const padded=s.replace(/-/g,'+').replace(/_/g,'/')+'='.repeat((4-s.length%4)%4); const bin=atob(padded); return Uint8Array.from(bin,c=>c.charCodeAt(0)); }

async function clientUrl(origin,event,env){
  if(!env.SESSION_SECRET) return null;
  const payload=`${event.id}:${event.client_access_version}`;
  const sig=b64url(new Uint8Array(await hmac(env.SESSION_SECRET,`client:${payload}`))).slice(0,32);
  return `${origin}/cliente/${encodeURIComponent(`${payload}.${sig}`)}`;
}
async function verifyClientToken(token,env){
  if(!env.SESSION_SECRET) return null;
  const lastDot=token.lastIndexOf('.'); if(lastDot<0) return null;
  const payload=token.slice(0,lastDot), sig=token.slice(lastDot+1);
  const colon=payload.lastIndexOf(':'); if(colon<0) return null;
  const eventId=payload.slice(0,colon), version=Number(payload.slice(colon+1));
  const expected=b64url(new Uint8Array(await hmac(env.SESSION_SECRET,`client:${payload}`))).slice(0,32);
  if(!(await safeSecretEqual(sig,expected,env.SESSION_SECRET))) return null;
  const event=await getEvent(env.DB,eventId);
  if(!event || Number(event.client_access_version)!==version) return null;
  return {event};
}

function makeCsv(rows){
  const header=['Nome','Status','Adultos','Crianças','Acompanhantes','Telefone','Restrição alimentar','Observações','Origem','Atualizado em'];
  const lines=[header,...rows.map(g=>[
    g.primary_name, statusLabel(g.response_status), g.adults, g.children, parseJson(g.companions_json,[]).join(' | '), g.phone||'', g.dietary||'', g.notes||'', g.source||'', g.updated_at||''
  ])];
  return lines.map(cols=>cols.map(csvCell).join(';')).join('\r\n');
}
function csvCell(v){ const s=String(v??''); return `"${s.replace(/"/g,'""')}"`; }
function statusLabel(s){ return s==='yes'?'Confirmado':s==='no'?'Não irá':'Pendente'; }
function safeFilename(s){ return String(s||'evento').replace(/[^a-zA-Z0-9_-]+/g,'-'); }
function json(data,status=200,headers={}){ return Response.json(data,{status,headers:{'Cache-Control':'no-store','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff',...headers}}); }
